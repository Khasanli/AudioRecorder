//
//  ViewController.swift
//  AudioRecorderEnvato
//
//  Created by Khayala Hasanli on 22.06.22.
//

import UIKit

class ViewController: UIViewController {

    let recorderView = RecorderView(backgroundColor: .clear)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setView()
    }
    
    private func setView(){
        view.addSubview(recorderView)
        recorderView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        recorderView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        recorderView.heightAnchor.constraint(equalTo: view.heightAnchor).isActive = true
        recorderView.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
    }
}

