//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifndef LibraryMP3-Bridging-Header_h
#define LibraryMP3-Bridging-Header_h

#import "ConvertMp3.h"
#import "AmrCodec.h"

#endif 
