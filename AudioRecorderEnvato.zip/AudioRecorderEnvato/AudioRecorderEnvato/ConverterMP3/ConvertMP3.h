//
//  ConvertMP3.h
//  LibraryMP3
//
//  Created by Khayala Hasanli on 15.06.22.
//

#import <Foundation/Foundation.h>

@interface ConvertMp3 : NSObject

- (void) audioPCMtoMP3:(NSString *)audioFileSavePath mp3File:(NSString *)mp3FilePath;
    
@end
