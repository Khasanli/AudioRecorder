//
//  File.swift
//  LibraryMP3
//
//  Created by Khayala Hasanli on 15.06.22.
//

import UIKit
import AVFoundation

enum RecordType :String {
    case Caf = "caf"
    case Wav = "wav"
}

class RecordManager: NSObject {
    
    var recorder: AVAudioRecorder?
    var player: AVAudioPlayer?
    var recordName:String?
    
    func beginRcord(recordType:RecordType){
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(AVAudioSession.Category.playAndRecord, mode: .default, options: .defaultToSpeaker)
        } catch let err{
            print("Error:\(err.localizedDescription)")
        }
        do {
            try session.setActive(true)
        } catch let err {
            print("Error:\(err.localizedDescription)")
        }
       
        let recordSetting: [String: Any] = [
            AVSampleRateKey: NSNumber(value: 16000),//采样率
            AVEncoderBitRateKey:NSNumber(value: 16000),
            AVFormatIDKey: NSNumber(value: kAudioFormatLinearPCM),//音频格式
            AVNumberOfChannelsKey: NSNumber(value: 1),//通道数
            AVLinearPCMBitDepthKey:NSNumber(value: 16),
            AVEncoderAudioQualityKey: NSNumber(value: AVAudioQuality.max.rawValue)//录音质量
        ];
        do {
            recordName = "Recordings"
            let fileType = (recordType == RecordType.Caf) ? "caf" : "wav"
            let filePath = NSHomeDirectory() + "/Documents/\(recordName!).\(fileType)"
            let url = URL(fileURLWithPath: filePath)
            recorder = try AVAudioRecorder(url: url, settings: recordSetting)
            recorder!.prepareToRecord()
            recorder!.record()
        } catch let err {
            print("Error:\(err.localizedDescription)")
        }
    }
    
    func stopRecord() {
        if let recorder = self.recorder {
            recorder.stop()
            print("record Stopped")
            self.recorder = nil
        }else {
            print("Recorder is not found")
        }
    }
    
    
    func stopRecordAndConvert(mp3Link: @escaping (URL) -> ()) {
        if let recorder = self.recorder {
            DispatchQueue.main.async {
                recorder.stop()
                self.recorder = nil
                self.convertCafToMp3()
                let mp3Path = NSHomeDirectory() + "/Documents/\(self.recordName!).mp3"
                let url = URL(fileURLWithPath: mp3Path)
                mp3Link(url)
            }
        }else {
            print("Cannot find Recorder")
        }
    }
    
    //播放
    func play(recordType:RecordType) {
        do {
            let fileType = (recordType == RecordType.Caf) ? "caf" : "wav"
            let filePath = NSHomeDirectory() + "/Documents/\(recordName!).\(fileType)"
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: filePath))
            print("Duration：\(player!.duration)")
            player!.play()
        } catch let err {
            print("Error on playing recording:\(err.localizedDescription)")
        }
    }
    
    func convertCafToMp3(){
        let audioPath = NSHomeDirectory() + "/Documents/\(recordName!).caf"
        let mp3Path = NSHomeDirectory() + "/Documents/\(recordName!).mp3"
        ConvertMp3().audioPCMtoMP3(audioPath, mp3File: mp3Path)
    }
    
    func convertCafToMp3Completion(completion: @escaping (URL) -> ()){
        let audioPath = NSHomeDirectory() + "/Documents/\(recordName!).caf"
        let mp3Path = NSHomeDirectory() + "/Documents/\(recordName!).mp3"
        ConvertMp3().audioPCMtoMP3(audioPath, mp3File: mp3Path)
        completion(URL(fileURLWithPath: mp3Path))
    }
    func convertWavToAmr(){
        let wavPath = NSHomeDirectory() + "/Documents/\(recordName!).wav"
        do {
            let wavData = try Data(contentsOf: URL(fileURLWithPath: wavPath))
            let amrData = convert16khzWaveToAmr(waveData: wavData)
            let amrPath = NSHomeDirectory() + "/Documents/\(recordName!).amr"
            try amrData?.write(to: URL(fileURLWithPath: amrPath))
            print("wavConvert：\(wavPath)")
            print("amrConvert：\(amrPath)")
        }catch let err {
            print("Error：\(err.localizedDescription)")
        }
    }
    
    func convertAmrToWav(){
        let amrPath = NSHomeDirectory() + "/Documents/\(recordName!).amr"
        do {
            let amrData = try Data(contentsOf: URL(fileURLWithPath: amrPath))
            let wavData = convertAmrWBToWave(data: amrData)
            let wavPath = NSHomeDirectory() + "/Documents/\(recordName!)_fromAmr.wav"
            try wavData?.write(to: URL(fileURLWithPath: wavPath))
            print("amrConvert：\(amrPath)")
            print("wavConvert：\(wavPath)")
        }catch let err {
            print("Error：\(err.localizedDescription)")
        }
    }
    
    func playWav(){
        do {
            let filePath = NSHomeDirectory() + "/Documents/\(recordName!)_fromAmr.wav"
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: filePath))
            print("Duration：\(player!.duration)")
            player!.play()
        } catch let err {
            print("Error:\(err.localizedDescription)")
        }
    }
    
    func playMP3(){
        do {
            let filePath = NSHomeDirectory() + "/Documents/\(recordName!).mp3"
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: filePath))
            print("Duration：\(player!.duration)")
            player!.play()
        } catch let err {
            print("Error:\(err.localizedDescription)")
        }
    }
    
}
