//
//  codec.h
//  SwiftAmrWaveConvertor
//
//  Created by zhenlintie on 2017/3/10.
//  Copyright © 2017年 sTeven. All rights reserved.
//

#ifndef codec_h
#define codec_h

#import "interf_dec.h"
#import "interf_enc.h"
#import "dec_if.h"
#import "enc_if.h"

#endif /* codec_h */
