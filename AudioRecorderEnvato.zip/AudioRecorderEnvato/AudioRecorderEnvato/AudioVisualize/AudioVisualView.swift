//
//  AudioVisualView.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 16.06.22.
//

import UIKit
import AVFoundation
import Accelerate

class AudioVisualizerView: UIView{
    var timer:Timer = Timer()
    var count:Int = 0
    var timerCounting:Bool = false

    var audioView = AudioVisualizer(backgroundColor: .clear)
    var voiceRecordTime = UILabel()
    var audioEngine = AVAudioEngine()
    private var renderTs: Double = 0
    private var recordingTs: Double = 0
    private var silenceTs: Double = 0
    override init(frame: CGRect) {
        super.init(frame: frame)
        setView()
    }
    
    private func setView(){
        addSubview(audioView)
        audioView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        audioView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 3).isActive = true
        audioView.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -3).isActive = true
        audioView.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true
    }
  
    func startAudioDetect(){
        self.audioEngine = AVAudioEngine()
        let inputNode = self.audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0).sampleRate
        let settings = [AVFormatIDKey: kAudioFormatLinearPCM, AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: true, AVSampleRateKey: Float64(recordingFormat), AVNumberOfChannelsKey: 1] as [String : Any]

        let audioFormat = AVAudioFormat(settings: settings)
        guard let format = audioFormat else {
            return
        }
        startTimer()
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { (buffer, time) in
            let level: Float = -50
            let length: UInt32 = 1024
            buffer.frameLength = length
            let channels = UnsafeBufferPointer(start: buffer.floatChannelData, count: Int(buffer.format.channelCount))
            var value: Float = 0
            vDSP_meamgv(channels[0], 1, &value, vDSP_Length(length))
            var average: Float = ((value == 0) ? -100 : 20.0 * log10f(value))
            if average > 0 {
                average = 0
            } else if average < -100 {
                average = -100
            }

            let silent = average < level
            let ts = NSDate().timeIntervalSince1970
            if ts - self.renderTs > 0.1 {
                let floats = UnsafeBufferPointer(start: channels[0], count: Int(buffer.frameLength))
                let frame = floats.map({ (f) -> Int in
                    return Int(f * Float(Int16.max))
                })
                DispatchQueue.main.async {
                    self.renderTs = ts
                    let len = self.audioView.waveforms.count
                    for i in 0 ..< len {
                        let idx = ((frame.count - 1) * i) / len
                        let f: Float = sqrt(1.5 * abs(Float(frame[idx])) / Float(Int16.max))
                        self.audioView.waveforms[i] = min(49, Int(f * 50))
                    }
                    self.audioView.active = !silent
                    self.audioView.setNeedsDisplay()
                }
            }
        }
        
        do {
            self.audioEngine.prepare()
            try self.audioEngine.start()
        } catch let error as NSError {
            print(error.localizedDescription)
            return
        }
    }
    
    func stopSounDetect(){
        self.stopTimer()
        self.audioEngine.inputNode.removeTap(onBus: 0)
        self.audioEngine.stop()
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch  let error as NSError {
            print(error.localizedDescription)
            return
        }
    }
    
    @objc func startTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerCounter), userInfo: nil, repeats: true)
    }
    
    @objc func timerCounter(){
        count = count + 1
        let time = secondsToHoursMinutesSeconds(seconds: count)
        let timeString = makeTimeString(hours: time.0, minutes: time.1, seconds: time.2)
        voiceRecordTime.text = timeString
    }
    
    @objc func stopTimer(){
        self.timer.invalidate()
        self.count = 0
        self.voiceRecordTime.text = self.makeTimeString(hours: 0, minutes: 0, seconds: 0)
    }
    
    func secondsToHoursMinutesSeconds(seconds: Int) -> (Int, Int, Int)
    {
        return ((seconds / 3600), ((seconds % 3600) / 60),((seconds % 3600) % 60))
    }
    
    func makeTimeString(hours: Int, minutes: Int, seconds : Int) -> String
    {
        var timeString = ""
        timeString += String(format: "%02d", hours)
        timeString += ":"
        timeString += String(format: "%02d", minutes)
        timeString += ":"
        timeString += String(format: "%02d", seconds)
        return timeString
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

