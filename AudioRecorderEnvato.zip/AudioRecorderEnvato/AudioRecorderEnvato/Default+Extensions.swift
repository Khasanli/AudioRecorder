//
//  Default+Extensions.swift
//  AudioRecorderEnvato
//
//  Created by Khayala Hasanli on 23.06.22.
//

import UIKit

let topPadding = UIApplication.topSafeAreaHeight
let screenSize = UIScreen.main.bounds
let titleBottom = (screenSize.width*1/3)+65+topPadding
let bigScreen = screenSize.width > 500 ? true : false
let bottomSize = bigScreen ? 80 : (screenSize.width/6)+5

class CustomizedSlider: UISlider{
    var sliderTrackHeight: CGFloat = 3
    override func trackRect(forBounds bounds: CGRect) -> CGRect {
        let originalRect = super.trackRect(forBounds: bounds)
        return CGRect(origin: CGPoint(x: originalRect.origin.x, y: originalRect.origin.y - (sliderTrackHeight/4)), size: CGSize(width: bounds.width, height: sliderTrackHeight))
    }
}

extension UIButton {
    convenience init(configuration: Bool = false, image: UIImage?, title: String?, tintColor: UIColor, backgroundColor: UIColor) {
        self.init()
        let tintedImage = image?.withRenderingMode(.alwaysTemplate)

        self.translatesAutoresizingMaskIntoConstraints = false
        self.setImage(tintedImage, for: .normal)
        self.setTitle(title, for: .normal)
        self.setTitleColor(tintColor, for: .normal)
        self.tintColor = tintColor

        if tintedImage != nil {
            self.backgroundColor = .clear
        } else {
            self.backgroundColor = backgroundColor
        }
        
        if configuration {
            if #available(iOS 15.0, *) {
                var configuration = UIButton.Configuration.gray()
                configuration.baseBackgroundColor  = .clear
                self.configuration = configuration
            } else {
                // Fallback on earlier versions
            }
        }
    }
}

extension UIButton {
    func setBackgroundColor(color: UIColor, forState: UIControl.State) {
       UIGraphicsBeginImageContext(CGSize(width: 1, height: 1))
       UIGraphicsGetCurrentContext()!.setFillColor(color.cgColor)
       UIGraphicsGetCurrentContext()!.fill(CGRect(x: 0, y: 0, width: 1, height: 1))
       let colorImage = UIGraphicsGetImageFromCurrentImageContext()
       UIGraphicsEndImageContext()
       self.setBackgroundImage(colorImage, for: forState)
    }
}

extension UILabel {
    convenience init(text: String, backgroundColor: UIColor?, textColor: UIColor?, font: UIFont) {
        self.init()
        self.adjustsFontSizeToFitWidth = true
        self.translatesAutoresizingMaskIntoConstraints = false
        self.font = font
        self.text = text
        self.textAlignment = .center
        if backgroundColor != nil {
            self.textColor = textColor
            self.backgroundColor = backgroundColor
        } else {
            self.textColor = textColor
            self.backgroundColor = .clear
        }
    }
  
}

extension UIView {
    convenience init(backgroundColor: UIColor) {
        self.init()
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = backgroundColor
    }
}

extension UIApplication {
    static var topSafeAreaHeight: CGFloat {
        var topSafeAreaHeight: CGFloat = 0
         if #available(iOS 11.0, *) {
             let scenes = UIApplication.shared.connectedScenes
             let windowScene = scenes.first as? UIWindowScene
             let window = windowScene?.windows.first
             let safeFrame = window?.safeAreaLayoutGuide.layoutFrame
             topSafeAreaHeight = safeFrame?.minY ?? 0
         }
        return topSafeAreaHeight
    }
}
