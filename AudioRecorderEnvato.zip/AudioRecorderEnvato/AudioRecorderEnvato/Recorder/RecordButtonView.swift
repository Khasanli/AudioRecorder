//
//  RecordButtonView.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 16.06.22.
//

import UIKit

class RecordButtonView: UIView {
    let recordButton = UIButton(image: UIImage(systemName: "mic"), title: nil, tintColor: .white, backgroundColor: .orange)
    let recordButtonbg1 = UIView(backgroundColor: .clear)
    let recordButtonbg2 = UIView(backgroundColor: .clear)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setView()
    }
    
    func setView(){
        addSubview(recordButtonbg1)
        recordButtonbg1.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        recordButtonbg1.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        recordButtonbg1.widthAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButtonbg1.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButtonbg1.layer.borderColor = UIColor.orange.cgColor
        recordButtonbg1.layer.borderWidth = 1
        
        addSubview(recordButtonbg2)
        recordButtonbg2.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        recordButtonbg2.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        recordButtonbg2.widthAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButtonbg2.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButtonbg2.layer.borderColor = UIColor.orange.cgColor
        recordButtonbg2.layer.borderWidth = 1
        
        addSubview(recordButton)
        recordButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        recordButton.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        recordButton.widthAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButton.heightAnchor.constraint(equalTo: self.heightAnchor, multiplier: 1/2).isActive = true
        recordButton.backgroundColor = .orange
        recordButton.tintColor = .white

    }
    
    @objc func animateBG(){
        recordButtonbg1.isHidden = false
        recordButtonbg2.isHidden = false
        
        UIView.animate(withDuration: 2, delay: 0, options: .repeat) {
            self.recordButtonbg1.transform = CGAffineTransform(scaleX: 2, y: 2)
            self.recordButtonbg1.alpha = 0
        } completion: { _ in
            self.recordButtonbg1.alpha = 1
        }

        UIView.animate(withDuration: 2, delay: 1, options: [.repeat]) {
            self.recordButtonbg2.transform = CGAffineTransform(scaleX: 2, y: 2)
            self.recordButtonbg2.alpha = 0
        } completion: { _ in
            self.recordButtonbg2.alpha = 1
            
        }
    }
    
    @objc func stopAnimateBG(){
        self.recordButtonbg2.transform = CGAffineTransform(scaleX: 1, y: 1)
        self.recordButtonbg1.transform = CGAffineTransform(scaleX: 1, y: 1)
        recordButtonbg1.isHidden = true
        recordButtonbg2.isHidden = true
        recordButtonbg1.layer.removeAllAnimations()
        recordButtonbg2.layer.removeAllAnimations()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
