//
//  UploadFileManager.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 18.06.22.
//

import UIKit
import UniformTypeIdentifiers
import MobileCoreServices

class UploadFileManager {
    func uploadAudioFile(url: String, token: String?, audioPath: URL, parameters: [String: Any], completion: @escaping (Result<Bool, Error>) -> Void) {
        let boundary = "Boundary-\(UUID().uuidString)"
        let files = [
            (
                name: "answer" ,
                path: audioPath
            )
        ]

        let session = URLSession.shared
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        guard token != nil, token != "" else {
            completion(.failure(fatalError()))
            return
        }
        
        request.setValue("\(token!)", forHTTPHeaderField: "Authorization")

        do{
            
            request.httpBody = try createBody ( with: parameters, files: files, boundary: boundary)
            
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
            if let error = error {
                print(error)
                completion(.failure(error))
                return
            }
    
            
            if let response = response {
                print(response)
                let nsHTTPResponse = response as! HTTPURLResponse
                let statusCode = nsHTTPResponse.statusCode
                if 400..<500 ~= statusCode{
                    completion(.failure(fatalError()))
                    return
                } else if 200..<300 ~= statusCode {
                    completion(.success(true))
                } else if statusCode == 500 {
                    completion(.failure(fatalError()))
                    return
                }else if statusCode > 500 {
                    completion(.failure(fatalError()))
                    return
                }
            }})
            task.resume()
            }catch let error {
                completion(.failure(error))
            }
    }
    
    private func createBody (with parameters: [ String: Any]?, files: [( name:String, path: URL )], boundary: String ) throws -> Data {
        var body = Data()

        if parameters != nil {
            for ( key, value ) in parameters! {
                body.append ( "--\(boundary)\r\n" )
                body.append ( "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n" )
                body.append ( "\(value)\r\n" )
            }
        }
        
         
        for file in files {
            print("File/URL: \(file.path)")
            let filename = file.path.lastPathComponent
            print("File/Name: \(filename)")
            let data = try Data (contentsOf: file.path)
            let mimetype = mimeType ( pathExtension: file.path.pathExtension )
            print("Mimetype: \(mimetype)")

            body.append ( "--\(boundary)\r\n" )
            body.append ( "Content-Disposition: form-data;" + "name=\"\(file.name)\"; filename=\"\(filename)\"\r\n" )
            body.append ( "Content-Type: \(mimetype)\r\n\r\n" ) //file type

            body.append ( data )
            body.append ( "\r\n" )
        }
        body.append ( "--\(boundary)--\r\n" )
        print("Body: \(body)")
        return body
    }
     
    func mimeType ( pathExtension: String ) -> String {
        if let uti = UTTypeCreatePreferredIdentifierForTag ( kUTTagClassFilenameExtension,
                                                           pathExtension as NSString,
                                                           nil )? .takeRetainedValue () {
            if let mimetype = UTTypeCopyPreferredTagWithClass ( uti, kUTTagClassMIMEType )?
                .takeRetainedValue ( ) {
                return mimetype as String
            }
        }
        return "application/octet-stream"
    }
}

extension Data {
    mutating func append( _ string: String, using encoding: String.Encoding = .utf8 ) {
        if let data = string.data ( using: encoding ) {
            append ( data )
        }
    }
}
