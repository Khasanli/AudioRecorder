//
//  VoivePlayerView.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 13.06.22.
//

import UIKit
import AVFoundation

class VoicePlayerView : UIView {
    let overBG = UIView(backgroundColor: .darkGray.withAlphaComponent(0.5))
    let playerButton = UIButton(image: UIImage(systemName: "play"), title: nil, tintColor: .black, backgroundColor: .clear)
    let passedTime = UILabel(text: "00:00", backgroundColor: .clear, textColor: .black, font: UIFont(name: "Arial", size: 12)!)
    
    var player: AVPlayer?
    var playerItem: AVPlayerItem?
    fileprivate let seekDuration: Float64 = 10
    
    var playerLink: URL? {
        didSet {
            guard let playerLink = playerLink else {
                disablePlayer()
                return
            }
            playerLinkString = playerLink.absoluteString
            playerButton.isUserInteractionEnabled = true
            voiceProgressBar.isUserInteractionEnabled = true
            playerItem = AVPlayerItem(url: playerLink)
            player = AVPlayer(playerItem: playerItem)
            overBG.isHidden = true
            initAudioPlayer()
        }
    }
    
    var playerLinkString: String?
    
    let voiceProgressBar = CustomizedSlider(backgroundColor: .clear)
    
    let muteButtonButton = UIButton(image: UIImage(systemName: "play"), title: nil, tintColor: .black, backgroundColor: .clear)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setView()
        disablePlayer()
    }
    
    func setView(){
        addSubview(playerButton)
        playerButton.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        playerButton.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        playerButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        playerButton.heightAnchor.constraint(equalToConstant: 20).isActive = true
        playerButton.addTarget(self, action: #selector(playButton), for: .touchUpInside)

        addSubview(passedTime)
        passedTime.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        passedTime.leftAnchor.constraint(equalTo: playerButton.rightAnchor).isActive = true
        passedTime.heightAnchor.constraint(equalToConstant: 30).isActive = true
        passedTime.widthAnchor.constraint(equalToConstant: 50).isActive = true

        addSubview(voiceProgressBar)
        voiceProgressBar.centerYAnchor.constraint(equalTo: playerButton.centerYAnchor).isActive = true
        voiceProgressBar.leftAnchor.constraint(equalTo: passedTime.rightAnchor).isActive = true
        voiceProgressBar.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        voiceProgressBar.heightAnchor.constraint(equalToConstant: 2).isActive = true
        voiceProgressBar.addTarget(self, action: #selector(playbackSliderValueChanged), for: .valueChanged)
        voiceProgressBar.setThumbImage(UIImage(named: "thumb1x"), for: .normal)
        voiceProgressBar.minimumTrackTintColor = .gray
        
        addSubview(overBG)
        overBG.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        overBG.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        overBG.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        overBG.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true
    }
    
    func disablePlayer(){
        self.overBG.isHidden = false
        self.playerButton.isUserInteractionEnabled = false
        self.voiceProgressBar.isUserInteractionEnabled = false
        self.voiceProgressBar.value = 0
        if player != nil {
            self.pausePlayer()
        }
        self.passedTime.text = "00:00"
    }
    
    func initAudioPlayer(){
        voiceProgressBar.minimumValue = 0
        voiceProgressBar.value = 0
        guard let playerItem = playerItem else {
            playerButton.isUserInteractionEnabled = false
            voiceProgressBar.isUserInteractionEnabled = false
            return
        }
        
        guard let player = player else {
            playerButton.isUserInteractionEnabled = false
            voiceProgressBar.isUserInteractionEnabled = false
            return
        }
        playerButton.isUserInteractionEnabled = true
        voiceProgressBar.isUserInteractionEnabled = true

        let duration : CMTime = playerItem.asset.duration
        let seconds : Float64 = CMTimeGetSeconds(duration)
        
        let currentDuration : CMTime = playerItem.currentTime()
        let currentSeconds : Float64 = CMTimeGetSeconds(currentDuration)
        passedTime.text = self.stringFromTimeInterval(interval: currentSeconds)
        
        voiceProgressBar.maximumValue = Float(seconds)
        voiceProgressBar.isContinuous = true
        
        player.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: DispatchQueue.main) { (CMTime) -> Void in
            if self.player!.currentItem?.status == .readyToPlay {
                let time : Float64 = CMTimeGetSeconds(self.player!.currentTime());
                self.voiceProgressBar.value = Float ( time );
                self.passedTime.text = self.stringFromTimeInterval(interval: time)
            }
            let playbackLikelyToKeepUp = self.player?.currentItem?.isPlaybackLikelyToKeepUp
            if playbackLikelyToKeepUp == false{
                self.playerButton.isHidden = true
            } else {
                self.playerButton.isHidden = false
            }
        }
       
        
        voiceProgressBar.addTarget(self, action: #selector(playbackSliderValueChanged(_:)), for: .valueChanged)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.finishedPlaying(_:)), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerItem)
    }


    @objc func playbackSliderValueChanged(_ playbackSlider:UISlider) {
        let seconds : Int64 = Int64(playbackSlider.value)
        let targetTime:CMTime = CMTimeMake(value: seconds, timescale: 1)
        player!.seek(to: targetTime)
    }

    @objc func finishedPlaying( _ myNotification: NSNotification) {
        playerButton.setImage(UIImage(systemName: "play"), for: UIControl.State.normal)
        voiceProgressBar.value = 0
        let targetTime:CMTime = CMTimeMake(value: 0, timescale: 1)
        player!.seek(to: targetTime)
    }

    @objc func playButton(_ sender: Any) {
        if player?.rate == 0
        {
            player!.play()
            playerButton.setImage(UIImage(systemName: "pause"), for: UIControl.State.normal)
        } else {
            player!.pause()
            playerButton.setImage(UIImage(systemName: "play"), for: UIControl.State.normal)
        }
        
    }
    
    @objc func pausePlayer(){
        guard let player = player else {
            return
        }
        player.pause()
        playerButton.setImage(UIImage(systemName: "play"), for: UIControl.State.normal)
    }

    func stringFromTimeInterval(interval: TimeInterval) -> String {
        let interval = Int(interval)
        let seconds = interval % 60
        let minutes = (interval / 60) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
