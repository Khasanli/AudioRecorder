//
//  RecorderView.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 12.06.22.
//

import UIKit
import AVFoundation

class RecorderView: UIView {
    let recorderManager = RecordManager()
    let recordButton = RecordButtonView(backgroundColor: .clear)
    
    let recordPlayerView = VoicePlayerView(backgroundColor: .secondarySystemBackground)
    let audioVisualView = AudioVisualizerView(backgroundColor: .clear)
    let recordTimeLabel = UILabel(text: "00:00:00", backgroundColor: .clear, textColor: .gray, font: UIFont(name: "Arial", size: 14)!)
    
    var isRecording : Bool = false {
        didSet {
            if isRecording {
                self.recordButton.isUserInteractionEnabled = false
                self.recordButton.animateBG()
                self.audioVisualView.startAudioDetect()
                self.recordPlayerView.isHidden = true
                self.audioVisualView.isHidden = false
                self.recordTimeLabel.isHidden = false
                self.recorderManager.beginRcord(recordType: .Caf)
                self.recordButton.isUserInteractionEnabled = true
            } else  {
                self.recordButton.isUserInteractionEnabled = false
                self.recordButton.stopAnimateBG()
                self.audioVisualView.stopSounDetect()
                self.audioVisualView.isHidden = true
                self.recordTimeLabel.isHidden = true
                self.recorderManager.convertCafToMp3Completion { url in
                    self.recordPlayerView.playerLink = url
                    self.recordButton.isUserInteractionEnabled = false
                    self.recordPlayerView.isHidden = false
                }
                self.recordButton.isUserInteractionEnabled = true
            }
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        setView()
    }
    
    func setView(){
        addSubview(audioVisualView)
        audioVisualView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        audioVisualView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        audioVisualView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        audioVisualView.heightAnchor.constraint(equalToConstant: 46).isActive = true
        audioVisualView.voiceRecordTime = recordTimeLabel

        addSubview(recordButton)
        recordButton.topAnchor.constraint(equalTo: audioVisualView.bottomAnchor, constant: 10).isActive = true
        recordButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        recordButton.widthAnchor.constraint(equalToConstant: 92).isActive = true
        recordButton.heightAnchor.constraint(equalToConstant: 92).isActive = true
        recordButton.recordButton.layer.cornerRadius = 23
        recordButton.recordButtonbg1.layer.cornerRadius = 23
        recordButton.recordButtonbg2.layer.cornerRadius = 23
        recordButton.recordButton.addTarget(self, action: #selector(recordButtonTapped), for: .touchUpInside)
        
        addSubview(recordTimeLabel)
        recordTimeLabel.bottomAnchor.constraint(equalTo: audioVisualView.topAnchor, constant: -10).isActive = true
        recordTimeLabel.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        recordTimeLabel.heightAnchor.constraint(equalToConstant: 46).isActive = true
        
        addSubview(recordPlayerView)
        recordPlayerView.centerXAnchor.constraint(equalTo: audioVisualView.centerXAnchor).isActive = true
        recordPlayerView.centerYAnchor.constraint(equalTo: audioVisualView.centerYAnchor).isActive = true
        recordPlayerView.heightAnchor.constraint(equalToConstant: 46).isActive = true
        recordPlayerView.widthAnchor.constraint(equalTo: self.widthAnchor, constant: -80).isActive = true
        recordPlayerView.layer.cornerRadius = 23
        recordPlayerView.layer.masksToBounds = true
        recordPlayerView.isHidden = true
        recordPlayerView.disablePlayer()
    }
    
    @objc func recordButtonTapped(){
        switch AVAudioSession.sharedInstance().recordPermission {
        case .granted:
            self.isRecording = !self.isRecording
            print("Permission granted")
        case .denied:
            print("Permission denied")
        case .undetermined:
            print("Request permission here")
            AVAudioSession.sharedInstance().requestRecordPermission({ granted in
                if granted {
                    print("please try again to record")
                } else {
                    print("You need to give access")
                }
            })
        @unknown default:
            print("Unknown case")
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

